package com.webprj.project_green;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectGreenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectGreenApplication.class, args);
	}

}
